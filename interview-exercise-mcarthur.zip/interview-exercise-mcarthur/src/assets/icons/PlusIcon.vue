<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    role="presentation"
    class="cdr-icon_2.0.1"
  >
    <path
      d="M11 11H6c-.55228475 0-1 .4477153-1 1s.44771525 1 1
      1h5v5c0 .5522847.4477153 1 1 1s1-.4477153 1-1v-5h5c.5522847 0 1-.4477153
      1-1s-.4477153-1-1-1h-5V6c0-.55228475-.4477153-1-1-1s-1 .44771525-1 1v5z"
    />
  </svg>
</template>

<script>
export default {
  name: 'PlusIcon',
};
</script>
